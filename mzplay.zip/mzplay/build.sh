TERMUX_PKG_DESCRIPTION="Mzplay prediction"
TERMUX_PKG_LICENSE="MIT"
TERMUX_PKG_MAINTAINER="lazzyont TLG ： @lucas8166363"
TERMUX_PKG_VERSION=1.0
TERMUX_PKG_BUILD_IN_SRC=true
TERMUX_PKG_DEPENDS="python"
TERMUX_PKG_SRCURL="file://$TERMUX_PKG_BUILDER_DIR/mzplay.tar.gz"


# Remove this line (we don't need SHA256 for a single file)
TERMUX_PKG_SHA256="accd2d68f145279afef73d4fb1e7e9897c1a2cd6164a5486aa6721afbb414310"

termux_step_make_install() {
    install -Dm700 $TERMUX_PKG_BUILDER_DIR/files/mzplay $TERMUX_PREFIX/bin/mzplay
    install -Dm700 $TERMUX_PKG_BUILDER_DIR/files/files/mzplay.py $TERMUX_PREFIX/bin/files/mzplay.py
    chmod +x $TERMUX_PREFIX/bin/mzplay

}
